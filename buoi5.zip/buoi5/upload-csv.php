<!DOCTYPE html>
<html>
<body>

<form action="upload-csv-processing.php" method="post" enctype="multipart/form-data">
  Ban chon 1 file csv:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload file" name="submit">
</form>

</body>
</html>
