<?php session_start(); ?>
<?php
// Xóa session name
unset($_SESSION['email']);
unset($_SESSION['fullname']);
unset($_SESSION['id']);

// Xóa hết session
session_destroy();
?>
<?php
setcookie("email", "", time()-3600);
setcookie("fullname", "", time()-3600);
setcookie("id", "", time()-3600);

?>