<?php
class class_sinhvien{
  public $mssv;
	public $hoTen;
	public $ngaySinh;
	public function __construct($mssv,$hoTen, $ngaySinh){
    $this->mssv=$mssv;
		$this->hoTen=$hoTen;
		$this->ngaySinh=$ngaySinh;

	}
	public function __destruct(){
		echo "";
	}
}
class sinhvien extends class_sinhvien{
	public $tuoi;
	public function __construct($mssv,$hoTen, $ngaySinh, $tuoi){
		parent::__construct($mssv,$hoTen, $ngaySinh);
		$this->tuoi=$tuoi;
	}
}
$sv=new sinhvien("B1906337","Nguyễn Minh Phát","10/04/2001","22 tuổi");
echo ("Mã số sinh viên: {$sv->mssv}.<br/>Họ tên: {$sv->hoTen}.<br/>Ngày sinh: {$sv->ngaySinh}.<br/>Tuổi hiện tại: {$sv->tuoi}.");
?>