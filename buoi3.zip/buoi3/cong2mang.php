<?php
$a = array(344,224,223,7737,9922,-828);
$b = array(-344,-324,123,773,-9922,828);
if($a!==$b){
  echo "Tong 2 mang = " . array_sum($a) + array_sum($b);
}else{
  echo "loi khong cung do dai";
}