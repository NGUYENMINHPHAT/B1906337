<!DOCTYPE HTML>
<html>  
<body>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Mật khẩu: <input type="text" name="password"><br>
Ngày tháng năm sinh: <input type="text" name="date"><br>

<input type="submit">
</form>

</body>
</html>
